<footer class="d-footer">
    <div>
        &copy; <?php echo e(now()->format('Y')); ?> · Made by
        <a href="https://your1site.sy" target="_blank"rel="nofollow noopener noreferrer">
            Your1site
        </a>
    </div>
    <div class="d-footer-meta">
        <a href="" class="href">
            <i class="bi bi-facebook"></i>
        </a>
        <a href="" class="href">
            <i class="bi bi-twitter-x"></i>
        </a>
        <a href="" class="href">
            <i class="bi bi-linkedin"></i>
        </a>
    </div>
</footer>
<?php /**PATH E:\projects\y1s\edu_1\resources\views/admin/partials/footer.blade.php ENDPATH**/ ?>