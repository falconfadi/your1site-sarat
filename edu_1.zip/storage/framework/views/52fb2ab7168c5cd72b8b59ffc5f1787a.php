<aside class="d-sidebar">
    <div class="brand">
        <div class="brand-logo">
            EY
        </div>
        <div class="brand-text">
            <div class="brand-name">EduYouth</div>
            <div class="brand-tag">EY</div>
        </div>
    </div>

    <nav class="nav-section">
        <div class="nav-label">Workspace</div>

        <a class="nav-link <?php echo e(request()->routeIs('admin.home') ? 'is-active' : ''); ?>"
            href="<?php echo e(route('admin.home')); ?>">
            <i class="bi bi-house"></i>
            <span><?php echo e(__('admin.dashboard')); ?></span>
        </a>
       
    </nav>
    <div class="sidebar-footer">
        <div class="workspace">
            <div class="workspace-avatar">
                <?php echo e(ucfirst(substr(Auth::guard('admin')->user()->name, 0, 1))); ?>

            </div>
            <div class="workspace-text">
                <div class="workspace-name">
                    <?php echo e(Auth::guard('admin')->user()->email); ?></div>
                <div class="workspace-role">admin</div>
            </div>
        </div>
    </div>
</aside>
<?php /**PATH E:\projects\y1s\edu_1\resources\views/admin/partials/sidebar.blade.php ENDPATH**/ ?>