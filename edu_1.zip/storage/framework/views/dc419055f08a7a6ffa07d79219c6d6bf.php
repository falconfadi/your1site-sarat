<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale() == 'ar' ? 'ar':'en'); ?>" dir="<?php echo e(app()->getLocale() == 'ar' ? 'rtl':'ltr'); ?>">
<head>
<title>Course | <?php echo $__env->yieldContent('title'); ?> </title>
<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="description" content="Course Project">
<meta name="viewport" content="width=device-width, initial-scale=1">

<link rel="stylesheet" type="text/css" href="<?php echo e(asset('website/css/bootstrap4/bootstrap.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('website/plugins/fontawesome-free-5.0.1/css/fontawesome-all.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('website/plugins/OwlCarousel2-2.2.1/owl.carousel.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('website/plugins/OwlCarousel2-2.2.1/owl.theme.default.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('website/plugins/OwlCarousel2-2.2.1/animate.css')); ?>">
<?php if(app()->getLocale() == 'en'): ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('website/css/main_styles.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('website/css/responsive.css')); ?>">
<?php else: ?>
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('website/ar/css/main_styles.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('website/ar/css/responsive.css')); ?>">
<?php endif; ?>

<?php echo $__env->yieldPushContent('styles'); ?>


<script src="https://cdn.tailwindcss.com"></script>
<script>
    tailwind.config = {
        darkMode: 'class',
        plugins: [
            function({ addVariant }) {
                addVariant('dark', '&:where(.dark, .dark *)');
            }
        ]
    }
</script>
<!-- bootstrap icons -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
<!-- Alpine.js for simple mobile menu toggle (Optional but helpful) -->
<script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>

</head>
<body>

<div class="super_container">
<?php echo $__env->make('website.partials.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('website.partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>

<script src="<?php echo e(asset('website/js/jquery-3.2.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('website/css/bootstrap4/popper.js')); ?>"></script>
<script src="<?php echo e(asset('website/css/bootstrap4/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('website/plugins/greensock/TweenMax.min.js')); ?>"></script>
<script src="<?php echo e(asset('website/plugins/greensock/TimelineMax.min.js')); ?>"></script>
<script src="<?php echo e(asset('website/plugins/scrollmagic/ScrollMagic.min.js')); ?>"></script>
<script src="<?php echo e(asset('website/plugins/greensock/animation.gsap.min.js')); ?>"></script>
<script src="<?php echo e(asset('website/plugins/greensock/ScrollToPlugin.min.js')); ?>"></script>
<script src="<?php echo e(asset('website/plugins/OwlCarousel2-2.2.1/owl.carousel.js')); ?>"></script>
<script src="<?php echo e(asset('website/plugins/scrollTo/jquery.scrollTo.min.js')); ?>"></script>
<?php echo $__env->yieldPushContent('scripts'); ?>
<script src="<?php echo e(asset('website/plugins/easing/easing.js')); ?>"></script>

<?php if(app()->getLocale() == 'en'): ?>
<script src="<?php echo e(asset('website/js/custom.js')); ?>"></script>
<?php else: ?>
<script src="<?php echo e(asset('website/ar/js/custom.js')); ?>"></script>
<?php endif; ?>

</body>
</html>
<?php /**PATH E:\projects\y1s\edu_1\resources\views/website/layouts/app.blade.php ENDPATH**/ ?>