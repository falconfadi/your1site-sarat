<aside class="d-sidebar">
                <div class="brand">
                    <div class="brand-logo">
                        EY
                    </div>
                    <div class="brand-text">
                        <div class="brand-name">EduYouth</div>
                        <div class="brand-tag">EY</div>
                    </div>
                </div>

                <nav class="nav-section">
                    <div class="nav-label">Workspace</div>

                    <a class="nav-link is-active" href="index.html">
                        <i class="bi bi-house"></i>
                        <span>Dashboard</span>

                    </a>
                    <a class="nav-link" href="#">
                        <i class="bi bi-gear"></i>
                        <span>settings</span>
                        <span class="nav-badge pro">PRO</span>
                    </a>
                </nav>
                <div class="sidebar-footer">
                    <div class="workspace">
                        <div class="workspace-avatar">JD</div>
                        <div class="workspace-text">
                            <div class="workspace-name">John Doe</div>
                            <div class="workspace-role">admin</div>
                        </div>
                    </div>
                </div>
            </aside>
<?php /**PATH E:\projects\y1s\edu_1\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>