<footer class="d-footer">
                    <div>© 2026 · Designed by <a href="https://colorlib.com" target="_blank"
                            rel="nofollow noopener noreferrer">Colorlib</a></div>
                    <div class="d-footer-meta">
                        <span>v4.1.2</span>
                        <span>preview build</span>
                    </div>
                </footer>
<?php /**PATH E:\projects\y1s\edu_1\resources\views/partials/footer.blade.php ENDPATH**/ ?>