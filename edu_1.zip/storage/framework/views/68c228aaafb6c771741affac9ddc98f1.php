<header class="d-topbar">
                    <div class="crumbs">
                        <button class="hamburger" data-drawer-open="" aria-label="Open navigation">
                            <i class="bi bi-list"></i>
                        </button>
                        <span>Workspace</span>
                        <i class="bi bi-chevron-right sepx"></i>
                        <span class="current">Dashboard</span>
                    </div>
                    <div class="topbar-actions">
                        <button class="cmd" data-palette-open="">
                            <i class="bi bi-search"></i>
                            <span>Search...</span>
                            <kbd class="kbd">⌘K</kbd>
                        </button>

                        <div class="dd-wrap">
                            <button class="icon-btn btn--lg" data-dropdown="" aria-label="Notifications">
                                <i class="bi bi-bell"></i>
                                <span class="count danger count--sm">2</span>
                            </button>
                            <div class="dd-menu" role="menu">
                                <div class="dd-head">
                                    <svg viewBox="0 0 24 24">
                                        <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path>
                                        <path d="M13.73 21a2 2 0 0 1-3.46 0"></path>
                                    </svg>
                                    Notifications
                                </div>
                                <div class="dd-list">
                                    <a class="dd-item" href="#">
                                        <div class="dd-avatar a1">JD</div>
                                        <div class="dd-body">
                                            <div class="dd-text"><strong>John Doe</strong> liked your <em>post</em>
                                            </div>
                                            <div class="dd-time">5 MIN AGO</div>
                                        </div>
                                    </a>
                                </div>
                                <a class="dd-footer" href="#">View all notifications →</a>
                            </div>
                        </div>

                        <button class="icon-btn" id="themeToggle" aria-label="Toggle theme">
                            <svg viewBox="0 0 24 24"
                                fill="none" stroke="currentColor" stroke-width="1.8">
                                <path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"></path>
                            </svg>
                        </button>

                        <div class="dd-wrap">
                            <div class="avatar" data-dropdown="" tabindex="0" role="button" aria-label="Account menu">JD
                            </div>
                            <div class="dd-menu dd-profile" role="menu">
                                <div class="dd-profile-head">
                                    <div class="dd-profile-name">John Doe</div>
                                    <div class="dd-profile-email">john@adminator.app</div>
                                </div>
                                <a class="dd-menu-item" href="#">
                                    <i class="bi bi-gear"></i>
                                    Settings
                                </a>
                                <a class="dd-menu-item" href="#">
                                    <i class="bi bi-person"></i>
                                    Profile
                                </a>
                                <div class="dd-divider"></div>
                                <a class="dd-menu-item danger" href="#">
                                    <i class="bi bi-door-closed"></i>
                                    Logout
                                </a>
                            </div>
                        </div>
                    </div>
                </header>
<?php /**PATH E:\projects\y1s\edu_1\resources\views/partials/topbar.blade.php ENDPATH**/ ?>