<!doctype html>
<html lang="en" <?php if(app()->getLocale() == 'ar'): ?> dir="rtl" <?php endif; ?>>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>EduYouth | <?php echo $__env->yieldContent('title'); ?></title>
    <script>
        ! function() {
            try {
                var t = localStorage.getItem("dash26-theme"),
                    e = window.matchMedia("(prefers-color-scheme: dark)").matches;
                document.documentElement.setAttribute("data-theme", t || (e ?
                    "dark" : "light"))
            } catch (t) {
                document.documentElement.setAttribute("data-theme", "light")
            }
        }()
    </script>
    <script defer="defer" src="<?php echo e(asset('assets/js/runtime.js')); ?> "></script>
    <script defer="defer" src="<?php echo e(asset('assets/js/vendor-fullcalendar.js')); ?> ">
    </script>
    <script defer="defer" src="<?php echo e(asset('assets/js/vendor-chartjs.js')); ?> ">
    </script>
    <script defer="defer" src="<?php echo e(asset('assets/js/vendors.js')); ?> "></script>
    <script defer="defer" src="<?php echo e(asset('assets/js/2026.js')); ?> "></script>
    <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">
    
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            darkMode: 'class',
            plugins: [
                function({ addVariant }) {
                    addVariant('dark', '&:where(.dark, .dark *)');
                }
            ]
        }
    </script>

    <!-- bootstrap icons -->
    <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">

    <!-- Alpine.js for simple mobile menu toggle (Optional but helpful) -->
    <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
</head>

<body data-active="dashboard" data-crumbs="Workspace | Dashboard">
    <?php if(auth()->guard('admin')->check()): ?>
        <div class="shell">
            <?php echo $__env->make('admin.partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <div class="main">
                <?php echo $__env->make('admin.partials.topbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php echo $__env->yieldContent('content'); ?>
                <?php echo $__env->make('admin.partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        </div>
    <?php else: ?>
        <?php echo $__env->yieldContent('content'); ?>
    <?php endif; ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">

    <!-- jQuery (Required for Toastr) -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>

    <!-- Toastr JS -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.js"></script>

    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <script>
                        toastr['error'](<?php echo json_encode($error); ?>, {
                            closeButton: true,
                            tapToDismiss: false,
                            timeOut: 5,
                        });
                    </script>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <?php if(Session::has('error')): ?>
        <script>
            toastr['error'](<?php echo json_encode(Session::get('error')); ?>, {
                closeButton: true,
                tapToDismiss: false,
                timeOut: 5,
            });
        </script>
    <?php endif; ?>
    <?php if(Session::has('success')): ?>
        <script>
            toastr['success'](<?php echo json_encode(Session::get('success')); ?>, {
                closeButton: true,
                tapToDismiss: false,
                timeOut: 5,
            });
        </script>
    <?php endif; ?>
    <script>
        const themeToggleBtn = document.getElementById('themeToggle');
        themeToggleBtn.addEventListener('click', function () {

            if (document.documentElement.classList.contains('dark')) {
                document.documentElement.classList.remove('dark');
                localStorage.setItem('theme', 'light');
            } else {
                document.documentElement.classList.add('dark');
                localStorage.setItem('theme', 'dark');
            }
        });

        function changeLang(langCode) {
            const htmlElement = document.documentElement;
            htmlElement.setAttribute('lang', langCode);

            if (langCode === 'ar') {
                htmlElement.setAttribute('dir', 'rtl');
            } else {
                htmlElement.setAttribute('dir', 'ltr');
            }
        }

        if (localStorage.getItem('theme') === 'dark' || (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
            document.documentElement.classList.add('dark');
        } else {
            document.documentElement.classList.remove('dark');
        }
    </script>
</body>

</html>
<?php /**PATH E:\projects\y1s\edu_1\resources\views/admin/layouts/app.blade.php ENDPATH**/ ?>