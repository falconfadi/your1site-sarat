

<?php $__env->startSection('title'); ?>
    Login
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="auth-shell">
        <aside class="auth-aside">
            <div class="auth-brand">
                <div class="logo">
                    EY
                </div>
                <div class="name">EduYouth</div>
            </div>
            <div class="auth-aside-body">
                <span class="auth-aside-eyebrow">2026 · 2027</span>
                <h1>The dashboard you want to have.</h1>
                <p>
                    Faster builds, cleaner tokens, and a design system that scales
                    from
                    a single chart to a 12-screen ops cockpit.
                </p>

            </div>
            <div class="auth-aside-footer">
                <span>© 2026</span> <span>BUILT IN RIGA, LV</span>
            </div>
        </aside>
        <main class="auth-main">
            
            <div class="auth-card">
                <h2>Welcome back</h2>
                <p class="sub">
                    Sign in to your workspace .
                </p>
                <form class="auth-form" method="post"
                    action="<?php echo e(route('admin.login')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="field">
                        <label class="field-label" for="email">Email</label>
                        <div class="input-icon">
                            <span class="ico">
                                <i class="bi bi-envelope"></i>
                            </span>
                            <input id="email"
                                class="input <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> input--error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="email" type="email"
                                placeholder="you@company.com"
                                value="<?php echo e(old('email')); ?>" autocomplete="email"
                                required />
                        </div>
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="error-message"
                                style="color: red; font-size: 0.85rem; display: block; margin-top: 0.25rem;">
                                <?php echo e($message); ?>

                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="field">
                        <div class="field-row">
                            <label class="field-label"
                                for="password">Password</label>
                            
                        </div>
                        <div class="input-icon">
                            <span class="ico">
                                <i class="bi bi-lock"></i>
                            </span>
                            <input id="password"
                                class="input <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> input--error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="password" type="password"
                                placeholder="••••••••"
                                autocomplete="current-password" required />
                        </div>
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="error-message"
                                style="color: red; font-size: 0.85rem; display: block; margin-top: 0.25rem;">
                                <?php echo e($message); ?>

                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    
                    <button class="btn btn--primary auth-submit" type="submit">
                        Sign in
                        <i class="bi bi-arrow-right"></i>
                    </button>
                </form>

            </div>
            <div class="auth-main-bottom">
            </div>
        </main>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\projects\y1s\edu_1\resources\views/admin/auth/login.blade.php ENDPATH**/ ?>