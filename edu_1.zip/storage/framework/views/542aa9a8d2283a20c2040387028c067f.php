<?php
    // Get all segments from the current URL path
    $segments = request()->segments();
    $url = '';
?>

<nav aria-label="breadcrumb" class="breadcrumbs-nav ">
    <ol class="breadcrumbs-list" style="display: flex; list-style: none; padding: 0; margin: 0; gap: 0.5rem; align-items: center;">
        
        
        

        
        <?php $__currentLoopData = $segments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $segment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                // Build the URL segment by segment
                $url .= '/' . $segment;
                $isLast = $loop->last;
                
                // Clean up the text (e.g., "user-profiles" becomes "User Profiles")
                $title = ucwords(str_replace(['-', '_'], ' ', $segment));
            ?>



            <li class="breadcrumb-item <?php echo e($isLast ? 'active' : ''); ?>" <?php echo e($isLast ? 'aria-current=page' : ''); ?>>
                <?php if($isLast): ?>
                    
                    <span style="color: #6c757d; font-weight: 500;"><?php echo e($title); ?></span>
                <?php else: ?>
                    
                    <a href="<?php echo e($url); ?>" style="text-decoration: none; color: var(--primary-color, #007bff);">
                        <?php echo e($title); ?>

                    </a>
                <?php endif; ?>
            </li>

            
            <span class="breadcrumb-separator" style="color: #6c757d; font-size: 0.85rem;">
                
                .
            </span>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ol>
</nav>
<?php /**PATH E:\projects\y1s\edu_1\resources\views/components/breadcrumbs.blade.php ENDPATH**/ ?>