

<?php $__env->startSection('title'); ?>
    Settings
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <main class="content">
        <div class="grid">
            <section class="col-12 card h-screen">
                <div class="card-head">
                    <div class="card-title-wrap">
                        <?php if (isset($component)) { $__componentOriginal1916c1d09b923261f3b7ac95b6e9930f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal1916c1d09b923261f3b7ac95b6e9930f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.titles','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('titles'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal1916c1d09b923261f3b7ac95b6e9930f)): ?>
<?php $attributes = $__attributesOriginal1916c1d09b923261f3b7ac95b6e9930f; ?>
<?php unset($__attributesOriginal1916c1d09b923261f3b7ac95b6e9930f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal1916c1d09b923261f3b7ac95b6e9930f)): ?>
<?php $component = $__componentOriginal1916c1d09b923261f3b7ac95b6e9930f; ?>
<?php unset($__componentOriginal1916c1d09b923261f3b7ac95b6e9930f); ?>
<?php endif; ?>
                        <span class="badge text-xs font-light"><?php echo e(count($settings)); ?> RECORDS</span>
                    </div>
                    <?php if (isset($component)) { $__componentOriginal9f64f32e90b9102968f2bc548315018c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9f64f32e90b9102968f2bc548315018c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.modal','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('modal'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                        <h3 class="text-base font-semibold leading-6 text-slate-900 dark:text-slate-100" id="modal-title mb-8">
                            Create New Setting
                        </h3>
                        <form class="space-y-5" action="<?php echo e(route('admin.settings.create')); ?>" method="POST" id="settingCreate">
                            <?php echo csrf_field(); ?>
                            <div>
                                <label for="name" class="block text-sm font-semibold text-slate-700 dark:text-slate-300 text-left rtl:text-right">
                                    Name
                                </label>
                                <div class="mt-1.5">
                                    <input id="name" name="name" type="text" autocomplete="name" required
                                        class="block w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3.5 py-2.5 text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 text-sm shadow-sm transition focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20">
                                </div>
                            </div>

                            <div>
                                <label for="value" class="block text-sm font-semibold text-slate-700 dark:text-slate-300 text-left rtl:text-right">
                                    Value
                                </label>
                                <div class="mt-1.5">
                                    <input id="value" name="value" type="value" autocomplete="value" required
                                        class="block w-full rounded-xl border border-slate-200 dark:border-slate-700 bg-white dark:bg-slate-800 px-3.5 py-2.5 text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-500 text-sm shadow-sm transition focus:border-blue-500 focus:outline-none focus:ring-2 focus:ring-blue-500/20">
                                </div>
                            </div>
                        </form>
                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $attributes = $__attributesOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__attributesOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9f64f32e90b9102968f2bc548315018c)): ?>
<?php $component = $__componentOriginal9f64f32e90b9102968f2bc548315018c; ?>
<?php unset($__componentOriginal9f64f32e90b9102968f2bc548315018c); ?>
<?php endif; ?>
                </div>
                <div class="table-scroll h-full">
                    <table class="table">
                        <thead>
                            <tr>
                                <th>id</th>
                                <th>Name</th>
                                <th>Value</th>
                                <th>created_at</th>
                                <th>Opteions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $setting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="cell-name">#<?php echo e($setting->id); ?></td>
                                    <td><?php echo e($setting->name); ?></td>
                                    <td>
                                        <span
                                            class="tag t-used"><?php echo e($setting->value); ?></span>
                                    </td>
                                    <td class="cell-date">
                                        <?php echo e($setting->created_at->format('Y-m-d')); ?>

                                    </td>
                                    <td>
                                        <?php echo $__env->make('admin.partials.dropdown', [
                                            'links'=>[
                                                'edit' => [
                                                    'url'=>route('admin.settings.edit',['id'=>$setting->id]),
                                                    'icon' => 'bi-pencil',
                                                    ],
                                                'delete' => [
                                                    'url'=>route('admin.settings.delete',['id'=>$setting->id]),
                                                    'icon' => 'bi-trash',
                                                    ]
                                            ] 
                                        ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <h2 class="text-2xl text-red-600">no result found
                                </h2>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </section>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH E:\projects\y1s\edu_1\resources\views/admin/settings/all.blade.php ENDPATH**/ ?>