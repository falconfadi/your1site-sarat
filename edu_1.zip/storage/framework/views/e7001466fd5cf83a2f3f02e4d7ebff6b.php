<?php
    $segments = request()->segments();
    $title = '';
?>

<nav aria-label="breadcrumb" class="breadcrumbs-nav ">
    <ol class="breadcrumbs-list" style="display: flex; list-style: none; padding: 0; margin: 0; gap: 0.5rem; align-items: center;">
        <?php $__currentLoopData = $segments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $segment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
                $title .= ucwords(str_replace(['-', '_'], ' ', $segment));
                $isLast = $loop->last;
                if(!$isLast){
	                $title .= ' . ';
                }
            ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <span class="eyebrow"><?php echo e($title); ?></span>
    </ol>
</nav>
<?php /**PATH E:\projects\y1s\edu_1\resources\views/components/titles.blade.php ENDPATH**/ ?>