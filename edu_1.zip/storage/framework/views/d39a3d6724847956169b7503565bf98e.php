<footer class="footer">
	<div class="container">
		<div class="newsletter">
			<div class="row">
				<div class="col">
					<div class="section_title text-center">
						<h1><?php echo e(__('website.footer.subscribe_to_news_letter')); ?></h1>
					</div>
				</div>
			</div>
			<div class="row">
				<div class="col text-center">
					<div class="newsletter_form_container mx-auto">
						<form action="post">
							<div class="newsletter_form d-flex flex-md-row flex-column flex-xs-column align-items-center justify-content-center">
								<input id="newsletter_email" class="newsletter_email" type="email" placeholder="Email Address" required="required" data-error="Valid email is required.">
								<button id="newsletter_submit" type="submit"
								class="newsletter_submit_btn trans_300" value="Submit">
								<?php echo e(__('website.footer.subscribe')); ?>

								</button>
							</div>
						</form>
					</div>
				</div>
			</div>
		</div>

		<!-- Footer Content -->
		<div class="footer_content">
		    <div class="row">
		        <div class="col-lg-3 footer_col">
		            <!-- Logo -->
		            <div class="logo_container">
		                <div class="logo">
		                    <img src="<?php echo e(asset('website/images/logo.png')); ?>" alt="Logo">
		                    <span><?php echo e(__('website.footer.logo_text')); ?></span>
		                </div>
		            </div>
		            <p class="footer_about_text">
		                <?php echo e(__('website.footer.about_text')); ?>

		            </p>
		        </div>

		        <div class="col-lg-3 footer_col">
		            <div class="footer_column_title"><?php echo e(__('website.footer.menu_title')); ?></div>
		            <div class="footer_column_content">
		                <ul>
		                    <li class="footer_list_item"><a href="<?php echo e(url('/')); ?>"><?php echo e(__('website.footer.menu_home')); ?></a></li>
		                    <li class="footer_list_item"><a href="<?php echo e(url('/courses')); ?>"><?php echo e(__('website.footer.menu_courses')); ?></a></li>
		                    <li class="footer_list_item"><a href="<?php echo e(url('/teachers')); ?>"><?php echo e(__('website.footer.menu_teachers')); ?></a></li>
		                    <li class="footer_list_item"><a href="<?php echo e(url('/news')); ?>"><?php echo e(__('website.footer.menu_news')); ?></a></li>
		                    <li class="footer_list_item"><a href="<?php echo e(url('/contact')); ?>"><?php echo e(__('website.footer.menu_contact')); ?></a></li>
		                </ul>
		            </div>
		        </div>

		        <div class="col-lg-3 footer_col">
		            <div class="footer_column_title"><?php echo e(__('website.footer.links_title')); ?></div>
		            <div class="footer_column_content">
		                <ul>
		                    <li class="footer_list_item"><a href="<?php echo e(url('/')); ?>"><?php echo e(__('website.footer.link_testimonials')); ?></a></li>
		                    <li class="footer_list_item"><a href="<?php echo e(url('/')); ?>"><?php echo e(__('website.footer.link_faq')); ?></a></li>
		                    <li class="footer_list_item"><a href="<?php echo e(url('/')); ?>"><?php echo e(__('website.footer.link_community')); ?></a></li>
		                    <li class="footer_list_item"><a href="<?php echo e(url('/')); ?>"><?php echo e(__('website.footer.link_gallery')); ?></a></li>
		                    <li class="footer_list_item"><a href="<?php echo e(url('/')); ?>"><?php echo e(__('website.footer.link_tuition')); ?></a></li>
		                </ul>
		            </div>
		        </div>

		        <div class="col-lg-3 footer_col">
		            <div class="footer_column_title"><?php echo e(__('website.footer.contact_title')); ?></div>
		            <div class="footer_column_content">
		                <ul>
		                    <li class="footer_contact_item">
		                        <div class="footer_contact_icon">
		                            <img src="<?php echo e(asset('website/images/placeholder.svg')); ?>" alt="Address Icon">
		                        </div>
		                        <?php echo e(__('website.footer.contact_address')); ?>

		                    </li>
		                    <li class="footer_contact_item">
		                        <div class="footer_contact_icon">
		                            <img src="<?php echo e(asset('website/images/smartphone.svg')); ?>" alt="Phone Icon">
		                        </div>
		                        <?php echo e(__('website.footer.contact_phone')); ?>

		                    </li>
		                    <li class="footer_contact_item">
		                        <div class="footer_contact_icon">
		                            <img src="<?php echo e(asset('website/images/envelope.svg')); ?>" alt="Email Icon">
		                        </div>
		                        <?php echo e(__('website.footer.contact_email')); ?>

		                    </li>
		                </ul>
		            </div>
		        </div>
		    </div>
		</div>


		<!-- Footer Copyright -->
		<div class="footer_bar d-flex flex-column flex-sm-row align-items-center">
			<div class="footer_copyright">
				<span></span>
			</div>
			<div class="footer_social ml-sm-auto">
				<ul class="menu_social">
					<li class="menu_social_item"><a href="#"><i class="fab fa-pinterest"></i></a></li>
					<li class="menu_social_item"><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
					<li class="menu_social_item"><a href="#"><i class="fab fa-instagram"></i></a></li>
					<li class="menu_social_item"><a href="#"><i class="fab fa-facebook-f"></i></a></li>
					<li class="menu_social_item"><a href="#"><i class="fab fa-twitter"></i></a></li>
				</ul>
			</div>
		</div>
	</div>
</footer>
<?php /**PATH E:\projects\y1s\edu_1\resources\views/website/partials/footer.blade.php ENDPATH**/ ?>