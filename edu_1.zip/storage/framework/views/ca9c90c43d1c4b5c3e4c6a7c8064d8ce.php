<!doctype html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <title>EduYouth | </title>
        <script>!function () { try { var t = localStorage.getItem("dash26-theme"), e = window.matchMedia("(prefers-color-scheme: dark)").matches; document.documentElement.setAttribute("data-theme", t || (e ? "dark" : "light")) } catch (t) { document.documentElement.setAttribute("data-theme", "light") } }()</script>
        <script defer="defer" src="<?php echo e(asset('assets/js/runtime.js')); ?> "></script>
        <script defer="defer" src="<?php echo e(asset('assets/js/vendor-fullcalendar.js')); ?> "></script>
        <script defer="defer" src="<?php echo e(asset('assets/js/vendor-chartjs.js')); ?> "></script>
        <script defer="defer" src="<?php echo e(asset('assets/js/vendors.js')); ?> "></script>
        <script defer="defer" src="<?php echo e(asset('assets/js/2026.js')); ?> "></script>
        <link href="<?php echo e(asset('assets/css/style.css')); ?>" rel="stylesheet">
        <!-- bootstrap icons -->
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">

        <!-- Alpine.js for simple mobile menu toggle (Optional but helpful) -->
        <script defer src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js"></script>
    </head>

    <body data-active="dashboard" data-crumbs="Workspace | Dashboard">
        <div class="shell">
                <?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <div class="main">
                <?php echo $__env->make('partials.topbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php echo $__env->yieldContent('content'); ?>
                <?php echo $__env->make('partials.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            </div>
        </div>
    </body>

</html>
<?php /**PATH E:\projects\y1s\edu_1\resources\views/layouts/app.blade.php ENDPATH**/ ?>